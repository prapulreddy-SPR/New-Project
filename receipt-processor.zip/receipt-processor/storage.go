package main

var receiptStore = make(map[string]int)