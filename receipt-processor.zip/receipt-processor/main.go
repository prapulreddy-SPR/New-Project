package main

import (
    "encoding/json"
    "net/http"
    "github.com/google/uuid"
    "github.com/gorilla/mux"
)

func main() {
    router := mux.NewRouter()
    router.HandleFunc("/receipts/process", ProcessReceiptHandler).Methods("POST")
    router.HandleFunc("/receipts/{id}/points", GetPointsHandler).Methods("GET")
    http.ListenAndServe(":8080", router)
}
func ProcessReceiptHandler(w http.ResponseWriter, r *http.Request) {
	var receipt Receipt
	err := json.NewDecoder(r.Body).Decode(&receipt)
	if err != nil {
		http.Error(w, "Invalid input. Please verify input.", http.StatusBadRequest)
		return
	}
	points := CalculatePoints(receipt)
	id := uuid.New().String()
	receiptStore[id] = points
	json.NewEncoder(w).Encode(ProcessResponse{ID: id})
}

func GetPointsHandler(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]
	points, exists := receiptStore[id]
	if !exists {
		http.Error(w, "No receipt found for that ID.", http.StatusNotFound)
		return
	}
	json.NewEncoder(w).Encode(PointsResponse{Points: points})
}
